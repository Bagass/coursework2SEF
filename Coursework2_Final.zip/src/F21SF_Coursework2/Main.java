package F21SF_Coursework2;


/**
 * Main class
 * It instantiates a Manager object and runs it
 * @author Jérémie Koster
 *
 */
public class Main {
	public static void main(String[] args) throws Exception {
		
		Manager manager = new Manager();
		manager.run();
		
		
	}
}